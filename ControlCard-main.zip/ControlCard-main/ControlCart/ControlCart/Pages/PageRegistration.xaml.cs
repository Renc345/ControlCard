﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageRegistration.xaml
    /// </summary>
    public partial class PageRegistration : Page
    {
        public PageRegistration()
        {
            InitializeComponent();
        }

        private void registration_Click(object sender, RoutedEventArgs e)
        {
            //    if (ClassFrame.frmObj.Users.Count(x => x.login_users == login.Text) > 0)
            //    {
            //        MessageBox.Show("Пользователь с таким логином есть!", "Уведомление", MessageBoxButton.OK);
            //        return;
            //    }
            //    try
            //    {
            //        Users usersObj = new Users();
            //        {
            //            login_users = login.Text;
            //            pasword_users = password.Text;
            //            Id_User = 2;
            //        };
            //        ClassFrame.frmObj.Users.Add(usersObj);
            //        ClassFrame.frmObj.SaveChanges();
            //        MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK);
            //    }
            //    catch
            //    {
            //        MessageBox.Show("Ошибка при добавлении данных!", "Уведомление", MessageBoxButton.OK);
            //    }
        }

        private void enter_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new PageAuthorization());
        }
        private void check_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (check.Password != password.Password)
            {
                registration.IsEnabled = false;
                check.Background = Brushes.LightCoral;
                check.BorderBrush = Brushes.Red;
            }
            else
            {
                check.Background = Brushes.LightGreen;
                check.BorderBrush = Brushes.Green;
            }
        }
    }
}
