﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageRegistration.xaml
    /// </summary>
    public partial class PageRegistration : Page
    {
        public PageRegistration()
        {
            InitializeComponent();
            CmbRole.ItemsSource = ClassFrame.db.Type_users.ToList();
        }

        private void registration_Click(object sender, RoutedEventArgs e)
        {
            Users users = new Users();
            if (txtlogin.Text == "" && txtpassword.Password == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK);
            }
            users.login_users = txtlogin.Text;
            users.pasword_users = txtpassword.Password;
            var role = CmbRole.SelectedItem as Type_users;
            users.Id_Type_Users = role.Id_Type_Users;
            try
            {
                ClassFrame.db.Users.Add(users);
                ClassFrame.db.SaveChanges();
                MessageBox.Show("Все успешно добавлено");
                ClassFrame.frmObj.Navigate(new PageMenu());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

          
        private void enter_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAuthorization());
        }
        private void check_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (txtcheck.Password != txtpassword.Password)
            {
                registration.IsEnabled = false;
                txtcheck.Background = Brushes.LightCoral;
                txtcheck.BorderBrush = Brushes.Red;
            }
            else
            {
                registration.IsEnabled = true;
                txtcheck.Background = Brushes.LightGreen;
                txtcheck.BorderBrush = Brushes.Green;
            }
        }
    }
}
