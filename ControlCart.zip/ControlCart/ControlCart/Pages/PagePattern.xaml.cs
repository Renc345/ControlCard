﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ControlCart.Pages;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePattern.xaml
    /// </summary>
    public partial class PagePattern : Page
    {
        public PagePattern()
        {
            InitializeComponent();
            
        }
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            dgPatern.ItemsSource = ClassFrame.db.Pattern.Where(x => x. Title.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var paternForRemoving = dgPatern.SelectedItems.Cast<Pattern>().ToList();
            if (MessageBox.Show($"Удалить {paternForRemoving.Count()} шаблона?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ClassFrame.db.Pattern.RemoveRange(paternForRemoving);
                    ClassFrame.db.SaveChanges();
                    MessageBox.Show("Данные удалены");
                    dgPatern.ItemsSource = ClassFrame.db.Pattern.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void dgPatern_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PagePoints((Pattern)dgPatern.SelectedItem));
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void redact_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PagePoints((Pattern)dgPatern.SelectedItem));
        }
    }
}
