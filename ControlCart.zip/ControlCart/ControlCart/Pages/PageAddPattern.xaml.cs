﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddPattern.xaml
    /// </summary>
    public partial class PageAddPattern : Page
    {
        public PageAddPattern(Pattern selectedPatern)
        {
            InitializeComponent();
            CmbPattern.ItemsSource = ClassFrame.db.Pattern.ToList();
            CmbPoints.ItemsSource = ClassFrame.db.Points.ToList();
            CmbSubItems.ItemsSource = ClassFrame.db.Sub_Items.ToList();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            Pattern pattern = new Pattern();
            Points points = new Points();
            Sub_Items sub_items = new Sub_Items();

            var pattern1 = CmbPattern.SelectedItem as Pattern;
            if (pattern1 == null) 
            {
                pattern = new Pattern();
                pattern.Title = CmbPattern.Text;
                ClassFrame.db.Pattern.Add(pattern);
                ClassFrame.db.SaveChanges();
            }
            else
            {
                pattern1.Title = CmbPattern.Text;
            }

            var points1 = CmbPoints.SelectedItem as Points;
            if (points1 == null)
            {
                points = new Points();
                points.text_points = CmbPoints.Text;
                points.Id_Patern= pattern.Id_Patern;
                ClassFrame.db.Points.Add(points);
                ClassFrame.db.SaveChanges();
            }
            else
            {
               points1.text_points = CmbPoints.Text;
            }

            var sub_items1 = CmbPoints.SelectedItem as Sub_Items;
            if (sub_items1 == null)
            {
                sub_items= new Sub_Items();
                sub_items.text_sub_items = CmbSubItems.Text;
                sub_items.Id_Points = points.Id_Points;
                ClassFrame.db.Sub_Items.Add(sub_items);
                ClassFrame.db.SaveChanges();
            }
         
            else
            {
               sub_items.text_sub_items= CmbSubItems.Text;
            }

            try
            {
                ClassFrame.db.Pattern.Add(pattern);
                ClassFrame.db.SaveChanges();
                MessageBox.Show("Все успешно добавлено");
                ClassFrame.frmObj.Navigate(new PagePattern());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
