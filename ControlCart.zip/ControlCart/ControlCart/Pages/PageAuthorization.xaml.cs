﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAuthorization.xaml
    /// </summary>
    public partial class PageAuthorization : Page
    {
        public PageAuthorization()
        {
            InitializeComponent();
            login.Text = "";
            password.Password = "";
        }
        private void enter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (login.Text == "" && password.Password == "") MessageBox.Show("Заполните поля!", "Ошибка ввода полей", MessageBoxButton.OK);
                else
                {
                    Users users = ControlCardSMEntities.GetContext().Users.FirstOrDefault(x => x.login_users == login.Text && x.pasword_users == password.Password);
                    if (users == null) MessageBox.Show("Неверный логин или пароль!", "Ошибка ввода", MessageBoxButton.OK);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK); }
        }

        private void registration_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new PageRegistration());
        }
    }
}
